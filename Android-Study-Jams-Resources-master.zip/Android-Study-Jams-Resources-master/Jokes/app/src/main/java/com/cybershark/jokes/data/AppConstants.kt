package com.cybershark.jokes.data

object AppConstants {
    const val GITHUB_LINK = "https://github.com/DSCCUSAT/Android-Study-Jams-Resources"
}