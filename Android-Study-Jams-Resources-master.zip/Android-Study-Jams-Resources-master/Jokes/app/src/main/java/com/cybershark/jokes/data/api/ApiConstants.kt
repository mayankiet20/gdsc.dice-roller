package com.cybershark.jokes.data.api

object ApiConstants {
    const val apiEndpoint = "https://official-joke-api.appspot.com/"
}