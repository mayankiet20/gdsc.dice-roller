package com.cybershark.jokes.data

object SharedPreferencesKeys {
    const val THEME_OPTION_KEY = "darkTheme"
    const val ABOUT_INFO_KEY = "aboutInfo"
    const val SHARE_APP_KEY = "shareApp"
    const val DELETE_FAVORITES_KEY = "deleteFavorites"
}